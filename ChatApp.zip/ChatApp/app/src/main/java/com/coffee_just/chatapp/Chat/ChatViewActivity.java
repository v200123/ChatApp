package com.coffee_just.chatapp.Chat;

import android.support.v7.app.AppCompatActivity;

public class ChatViewActivity extends AppCompatActivity {

}
