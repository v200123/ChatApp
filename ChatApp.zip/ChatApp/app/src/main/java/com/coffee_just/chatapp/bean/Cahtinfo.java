package com.coffee_just.chatapp.bean;

public class Cahtinfo {
        private String ChatUserName;
        private  String ChatUserId;

    public Cahtinfo(String chatUserName, String chatUserId) {
        ChatUserName = chatUserName;
        ChatUserId = chatUserId;
    }
}
