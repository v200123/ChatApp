package com.coffee_just.chatapp.bean;

public class UserInfo {
        private String userName;
        private  String userId;

    public UserInfo(String userName, String userId) {
        this.userName = userName;
        this.userId = userId;
    }
}
