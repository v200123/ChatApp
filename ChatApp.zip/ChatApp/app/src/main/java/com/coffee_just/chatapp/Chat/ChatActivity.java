package com.coffee_just.chatapp.Chat;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import com.coffee_just.chatapp.Untils.L;
import com.hyphenate.EMConnectionListener;
import com.hyphenate.EMError;
import com.hyphenate.chat.EMClient;
import com.hyphenate.util.NetUtils;

public class ChatActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EMClient.getInstance().groupManager().loadAllGroups();
        EMClient.getInstance().chatManager().loadAllConversations();
        EMClient.getInstance().addConnectionListener(new MyConnectionListener());
    }


    private class MyConnectionListener implements EMConnectionListener {

        @Override
        public void onConnected() {

        }

        @Override
        public void onDisconnected(int errorCode) {
            runOnUiThread(new Runnable() {

                @Override
                public void run() {
                    if (errorCode == EMError.USER_REMOVED) {
                        // 显示帐号已经被移除
                    } else if (errorCode == EMError.USER_LOGIN_ANOTHER_DEVICE) {
                        // 显示帐号在其他设备登录
                        L.d("账号已经被踢出去了");
                        EMClient.getInstance().logout(true);
                    } else {
                        if (NetUtils.hasNetwork(ChatActivity.this)) {

                        }
                        //连接不到聊天服务器
                        else {
                                L.d("网络连接异常");
                        }
                        //当前网络不可用，请检查网络设置
                    }
                }
            });
        }
    }

}
